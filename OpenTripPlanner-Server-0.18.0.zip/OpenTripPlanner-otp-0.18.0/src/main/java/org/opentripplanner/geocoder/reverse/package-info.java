/**
 * The "municoder" is a reverse geocoder.
 * It tells you which town or other administrative unit you're in based on lat/lon coordinates.
 */
package org.opentripplanner.geocoder.reverse;