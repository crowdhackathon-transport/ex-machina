package org.opentripplanner.analyst;

public class EmptyPolygonException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1073247256905676385L;

}
