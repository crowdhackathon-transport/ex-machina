/**
 * This package contains the JAX-RS-annotated REST resource classes for the OpenTripPlanner public
 * API, i.e. the Jersey REST endpoints. 
 */
package org.opentripplanner.api.resource;

