/**
 * This package contains classes which interpret incoming HTTP query parameters. Query parameters
 * arrive as Strings, and Jersey will automatically call constructors with a single String argument.
 */
package org.opentripplanner.api.parameter;

